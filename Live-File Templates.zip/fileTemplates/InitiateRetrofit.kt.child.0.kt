package ${PACKAGE_NAME}.remote

object EndPoints {

    const val BASE_URL = "https://www.example.com/"

    const val SAMPLE = "Sample.php"

}