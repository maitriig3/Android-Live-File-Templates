package ${PACKAGE_NAME}

class ${Name}Impl : ${Name}{
}