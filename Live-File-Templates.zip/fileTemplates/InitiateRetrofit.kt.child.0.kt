package ${PACKAGE_NAME}.data.remote

object EndPoints {

    const val BASE_URL = "https://www.example.com/"

    const val SAMPLE = "Sample.php"

}