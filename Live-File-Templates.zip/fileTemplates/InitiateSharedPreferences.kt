package ${PACKAGE_NAME}.data.local.preferences

object PreferencesKeys {
    const val SAMPLE_KEY = "sample_key"
}