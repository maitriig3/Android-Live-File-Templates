package ${PACKAGE_NAME}

interface ${Name} {
}